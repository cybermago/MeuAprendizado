package me.dio.academia.digital.entity.form;

public class AvaliacaoFisicaUpdateForm {

  private double peso;

  private double altura;
}
